# DISKSCHEDULER
Website simulating disk scheduling algorithms.

# Deployment link:
https://pranav-0.github.io/DISKSCHEDULER/index.html
